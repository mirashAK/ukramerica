<?php 
$ukamConfig_MetaDesc = 'Продажа лицензионного программного обеспечения и компьютерных комплектующих с установкой и бесплатной доставкой по Днепропетровску. Самые низкие цены на ПО. У нас можно приобрести Антивирус Касперского, NOD 32, DrWeb, а также программы производства Microsoft.';
$ukamConfig_MetaKeys = 'купить, приобрести, покупка, программы, программа, лицензионное программное обеспечение, антивирус, бест звит, windows, ПО, Лицензионное программное обеспечение, продажа, настройка, доставка, установка, сопровождение, низкие цены, Касперский, Kaspersky, ключи, продление, лицензия, купить лицензию, DrWeb, ДрВеб, выгодное предложение, дешево, купить в Днепропетровске, бесплатная доставка, Украина, по Украине, легализация Windows, легализировать Windows, купить антивирус, бесплатный софт, бесплатный антивирус, защита, защита данных, антивирусная защита, защита пк от вирусов, пк, купить антивирус в Днепропетровске, продление лицензии';
$ukamConfig_absolute_path = '/home/mirash/server/digitalsoft';
$ukamConfig_cachepath = '/home/mirash/server/digitalsoft/cache';
$ukamConfig_dbName = 'tolik4_db0';
$ukamConfig_dbprefix = 'ukam_';
$ukamConfig_favicon = 'favicon.ico';
$ukamConfig_live_site = 'http://server.ua/ukram';
$ukamConfig_host = 'localhost';
$ukamConfig_offline_message = 'сайт находится в тестовом режиме. Проводятся технические работы. Приносим свои извинения, за временные неудобства.';
$ukamConfig_wPassword = '3CJ4F6zr6tKI';
$ukamConfig_wUser = 'tolik4_db0';
$ukamConfig_orderEmail = 'ukramerica@gmail.com';
$ukamConfig_password = '3CJ4F6zr6tKI';
$ukamConfig_user = 'tolik4_db0';
$ukamConfig_minHeight = '900px';

define ('CONF_st_uplPath', "/upload/");
define ('CONF_st_abspath', dirname(__FILE__));
define ('CONF_sc_site', "http://".$_SERVER['SERVER_NAME']."/ukram");

define ('CONF_st_xDimension', 234);
define ('CONF_st_yDimension', 88);
define ('CONF_st_defaultBackColor', 0xFFFFFF);

define ('CONF_st_translit', "а|a,б|b,в|v,г|g,д|d,е|e,ё|e,ж|j,з|z,и|i,й|y,к|k,л|l,м|m,н|n,о|o,п|p,р|r,с|s,т|t,у|u,ф|f,х|h,ц|c,ч|ch,ш|sh,щ|shch,ы|y,э|e,ю|yu,я|ya,А|A,Б|B,В|V,Г|G,Д|D,Е|E,Ё|E,Ж|J,З|Z,И|I,Й|Y,К|K,Л|L,М|M,Н|N,О|O,П|P,Р|R,С|S,Т|T,У|U,Ф|F,Х|H,Ц|C,Ч|CH,Ш|SH,Щ|SHCH,Ы|Y,Э|E,Ю|YU,Я|YA,Ъ|,Ь|,ъ|,ь|, |-");
?>
