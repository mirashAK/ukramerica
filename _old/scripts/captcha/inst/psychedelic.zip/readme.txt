Configuration for Cryptographp v1.4
www.cryptographp.com


How to install this configuration:
----------------------------------


- Replace the file �cryptographp.cfg.php� by that in this package